import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
public class TriangleShape implements Shape{
	public void setLocation(Point p){
		t=p;
	}
	public Point getLocation()
	{
		return t;
	}
	@Override
	public boolean contains(Point2D arg0) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean contains(Rectangle2D arg0) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean contains(double arg0, double arg1) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean contains(double arg0, double arg1, double arg2, double arg3) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public Rectangle getBounds() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Rectangle2D getBounds2D() {
		// TODO Auto-generated method stub
		return null;
	}
	public PathIterator getPathIterator(AffineTransform arg0) {
		GeneralPath path1;
		//Drawing Triangle of 100,200,200 as its sides. 
		final double vertex1_X=100;
		final double vertex1_Y=100;
		final double vertex2_X=200;
		final double vertex2_Y=100;
		final double vertex3_X=150;
		final double vertex3_Y=293.6491673103708;

		path1 = new GeneralPath();
		path1.moveTo(vertex1_X,vertex1_Y);//Taking origin at (100,100).
		path1.lineTo(vertex2_X,vertex2_Y);//Drawing line of 100 unit in X-direction.
		path1.lineTo(vertex3_X,vertex3_Y);//Drawing line  towards another vertex of Triangle. 
		path1.lineTo(vertex1_X,vertex1_Y);// drawing line to its initial point.
		return path1.getPathIterator(arg0); 
	}

	@Override
	public PathIterator getPathIterator(AffineTransform arg0, double arg1) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean intersects(Rectangle2D arg0) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean intersects(double arg0, double arg1, double arg2, double arg3) {
		// TODO Auto-generated method stub
		return false;
	}
	private Point t;//new Point();
}

