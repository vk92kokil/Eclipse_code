There are total 4 programs that i have uploaded here in this zip file.
the program "Triangle.java" is the same code which was there on Assignment 
folder.
The method setLocation() and getLocation() is defined in TriangleComponentTester.java,and
there are some empty implementation of interface methods that are not required.
I have used the co-ordinates of the vertex of triangle in the file TriangleComponentTester.java
which was necessary to draw a Triangle of dimension 100,200,200.
