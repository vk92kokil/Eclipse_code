import javax.swing.JFrame;
public class TriangleComponentTester {
	public static void main(String[] args){
		JFrame frame=new JFrame();
		frame.setSize(320, 350);
		frame.setTitle("Triangle of size(100,200,200)");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		TriangleComponent comp=new TriangleComponent();
		frame.add(comp);
		frame.setVisible(true);
		
	}
}
